# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Julio Angulo
"""Exercise colour lines through the real plugin loader, host and IGZ codec."""
from pathlib import Path
import sys
from types import SimpleNamespace

import pytest
from PySide6.QtGui import QMatrix4x4, QVector3D as V
from core.group import Group, copy_group
from core.history import History, MoveGroupCommand
from core.layers import Layer
from core.scene import Scene
from formats import igz

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "JA_LineaStyle_IngeTrazo"


@pytest.fixture(autouse=True)
def isolated_lineastyle_language(qt_app):
    from PySide6.QtCore import QSettings
    settings = QSettings()
    key = "lineas_color/language"
    saved = settings.value(key)
    settings.remove(key)
    yield
    if saved is None:
        settings.remove(key)
    else:
        settings.setValue(key, saved)


@pytest.fixture(scope="module")
def colors():
    from core.extensions import discover_plugins
    loaded, errors = discover_plugins([PROJECT])
    assert not errors
    assert len(loaded) == 1 and loaded[0].stem == "lineas_color"
    assert loaded[0].tools == [] and callable(loaded[0].setup)
    plugin = sys.modules["ingetrazo_plugin_lineas_color"]
    from importlib import import_module
    model = import_module(plugin.__name__ + ".model")
    return plugin, model


@pytest.fixture
def color_window(colors, monkeypatch):
    from core import extensions
    from views.main_window import MainWindow
    monkeypatch.setattr(extensions, "plugin_dirs", lambda: [PROJECT])
    win = MainWindow()
    win._autosave_timer.stop()
    yield win
    win.hide()
    win.deleteLater()


def controller(win):
    return win._lineas_color_controllers["lineas_color"]


@pytest.mark.parametrize("host_language,expected", [("en-US", "en"), ("fr-FR", "fr"), ("pt-BR", "es")])
def test_language_default_and_saved_preference(colors, monkeypatch, host_language, expected):
    from importlib import import_module
    from core import i18n
    from PySide6.QtCore import QSettings
    translations = import_module(colors[0].__name__ + ".i18n")
    monkeypatch.setattr(i18n, "current_language", lambda: host_language)
    QSettings().setValue(translations.SETTINGS_KEY, "unsupported")
    assert translations.Translator().language == expected
    translator = translations.Translator()
    translator.select("fr-CA")
    assert translations.Translator().language == "fr"
    assert i18n.current_language() == host_language
    assert translator.error("ColorSelection: El color debe tener el formato #RRGGBB.") == (
        "ColorSelection: La couleur doit respecter le format #RRGGBB.")


@pytest.mark.parametrize("language,draw,red,pattern,length,error,cancel,title", [
    ("en", "Draw coloured line", "Red", "Dash-dot", "Length",
     "First select the lines you want to colour.", "Cancel", "Line colour"),
    ("fr", "Tracer une ligne de couleur", "Rouge", "Trait mixte", "Longueur",
     "Sélectionnez d’abord les lignes à colorer.", "Annuler", "Couleur de la ligne"),
])
def test_switch_language_preserves_live_drawing_and_localizes_dialog(
        color_window, colors, monkeypatch, language, draw, red, pattern, length, error, cancel, title):
    from core import i18n
    from PySide6.QtCore import QSettings
    from PySide6.QtWidgets import QAbstractButton, QMenu
    from importlib import import_module
    c, vp = controller(color_window), color_window.viewport
    c.language_combo.setCurrentIndex(c.language_combo.findData("es"))
    c.choose("#1e88e5")
    c.width_spin.setValue(5)
    c.pattern_combo.setCurrentIndex(4)
    vp.scene.groups.clear()
    c.start_drawing()
    click_line(c.tool, vp, V(0, 0, 1))
    click_line(c.tool, vp, V(2, 0, 1))
    group, session = c.tool.session.group, c.tool.session
    start = V(c.tool.start_point)
    history_size = len(vp.history.undo_stack)
    host_language = i18n.current_language()
    c.language_combo.setCurrentIndex(c.language_combo.findData(language))
    assert c.draw_button.text() == draw
    assert c.palette_buttons[0][0].text() == red
    assert c.pattern_combo.currentText() == pattern
    assert c.tool.vcb_label == length and color_window._vcb_name.text() == length
    assert c.dock.windowTitle() == "LineaStyle"
    assert c.color == "#1e88e5" and c.width_px == 5 and c.pattern == "dash_dot"
    assert vp.active_tool is c.tool and c.tool.session is session
    assert c.tool.start_point == start and len(vp.history.undo_stack) == history_size
    assert i18n.current_language() == host_language
    click_line(c.tool, vp, V(2, 0, 3))
    assert vp.scene.groups == [group] and len(group.mesh.edges) == 2
    assert all(style == ("#1e88e5", 5.0, "dash_dot") for style in colors[1].edge_styles(group).values())
    assert QSettings().value("lineas_color/language") == language
    translations = import_module(colors[0].__name__ + ".i18n")
    assert translations.Translator().language == language
    menu = QMenu()
    c.context_menu(menu, {group})
    assert menu.actions()[0].menu().actions()[0].text() == red
    messages = []
    monkeypatch.setattr(vp, "flash_status", lambda message, *_args: messages.append(message))
    vp.scene.selection.clear()
    c.apply()
    assert messages[-1] == error
    dialog = c.create_color_dialog()
    assert dialog.windowTitle() == title
    assert cancel in [button.text() for button in dialog.findChildren(QAbstractButton)]
    dialog.deleteLater()


def ends(group):
    return [(tuple(e.a.toTuple()), tuple(e.b.toTuple())) for e in group.mesh.edges]


def test_create_save_open_move_and_copy(colors, tmp_path):
    _, model = colors
    scene = Scene()
    history = History(scene)
    cmd = model.CreateLine(V(0, 0, 1), V(3, 0, 1), "#E53935")
    history.execute(cmd)
    assert history.last_error is None
    assert scene.groups == [cmd.group]
    assert not scene.mesh.edges and not scene.selection
    assert model.group_color(cmd.group) == "#e53935"
    history.execute(MoveGroupCommand(cmd.group, V(0, 2, 0)))
    assert ends(cmd.group) == [((0, 2, 1), (3, 2, 1))]
    copied = copy_group(cmd.group, V(0, 2, 0))
    assert model.group_color(copied) == "#e53935"
    scene.groups.append(copied)
    path = tmp_path / "colours.igz"
    igz.save_scene(scene, path)
    restored = Scene()
    igz.load_into(restored, path)
    assert [model.group_color(g) for g in restored.groups] == ["#e53935"] * 2
    assert ends(restored.groups[0]) == [((0, 2, 1), (3, 2, 1))]
    assert ends(restored.groups[1]) == [((0, 4, 1), (3, 4, 1))]


def test_creation_undo_redo_and_new_document(colors):
    _, model = colors
    scene = Scene()
    history = History(scene)
    cmd = model.CreateLine(V(0, 0, 0), V(2, 1, 3), "#1e88e5")
    history.execute(cmd)
    for _ in range(3):
        assert history.undo() and not scene.groups
        assert history.redo() and scene.groups == [cmd.group]
        assert ends(cmd.group) == [((0, 0, 0), (2, 1, 3))]
    assert model.color_segments(Scene()) == {}


def test_convert_loose_wires_preserves_faces_and_tags(colors):
    _, model = colors
    scene = Scene()
    face = scene.mesh.add_face([V(0, 0, 0), V(1, 0, 0), V(1, 1, 0), V(0, 1, 0)])
    face.attrs["color"] = (0.7, 0.4, 0.1)
    edge = scene.mesh.add_edge(V(2, 0, 0), V(4, 0, 1))
    edge.layer = "Tubería"
    scene.selection = {edge}
    before = scene.mesh.capture_state()
    history = History(scene)
    cmd = model.ColorSelection(scene, "#43a047")
    history.execute(cmd)
    assert history.last_error is None
    assert len(scene.mesh.faces) == 1 and len(scene.mesh.edges) == 4
    assert face.attrs["color"] == (0.7, 0.4, 0.1)
    assert len(scene.groups) == 1
    assert scene.groups[0].layer == "Tubería"
    assert ends(scene.groups[0]) == [((2, 0, 0), (4, 0, 1))]
    assert history.undo()
    assert not scene.groups and edge in scene.mesh.edges
    assert scene.mesh.capture_state() == before
    assert history.redo()
    assert scene.groups == cmd.created


def test_recolor_reset_and_other_plugin_metadata(colors):
    _, model = colors
    scene = Scene()
    group = model.make_line(V(0, 0, 0), V(2, 0, 0), "#e53935")
    group.ext["another_plugin"] = {"note": "keep"}
    scene.groups.append(group)
    scene.selection = {group}
    history = History(scene)
    history.execute(model.ColorSelection(scene, "#1e88e5"))
    assert model.group_color(group) == "#1e88e5"
    assert group.ext["another_plugin"] == {"note": "keep"}
    assert history.undo() and model.group_color(group) == "#e53935"
    assert history.redo() and model.group_color(group) == "#1e88e5"
    scene.selection = {group}
    history.execute(model.ColorSelection(scene, None))
    assert model.group_color(group) is None
    assert group.ext == {"another_plugin": {"note": "keep"}}
    assert history.undo() and model.group_color(group) == "#1e88e5"


def test_recolor_and_reset_nested_line_groups(colors):
    _, model = colors
    scene = Scene()
    red = model.make_line(V(0, 0, 0), V(2, 0, 0), "#e53935")
    blue = model.make_line(V(0, 1, 0), V(2, 1, 0), "#1e88e5")
    parent = Group()
    parent.adopt([red, blue])
    scene.groups.append(parent)
    scene.selection = {parent}
    history = History(scene)
    history.execute(model.ColorSelection(scene, "#43a047"))
    assert set(model.color_segments(scene)) == {"#43a047"}
    assert history.undo()
    assert set(model.color_segments(scene)) == {"#e53935", "#1e88e5"}
    assert history.redo()
    scene.selection = {parent}
    history.execute(model.ColorSelection(scene, None))
    assert model.color_segments(scene) == {}
    assert all(model.group_color(g) is None for g in (parent, red, blue))


def test_surface_selection_is_rejected_before_mutation(colors):
    _, model = colors
    scene = Scene()
    face = scene.mesh.add_face([V(0, 0, 0), V(1, 0, 0), V(1, 1, 0)])
    wire = scene.mesh.add_edge(V(3, 0, 0), V(4, 0, 0))
    scene.selection = {wire, scene.mesh.edges[0]}
    before = scene.mesh.capture_state()
    with pytest.raises(ValueError, match="aristas de una cara"):
        model.ColorSelection(scene, "#e53935")
    assert scene.mesh.capture_state() == before and not scene.groups
    scene.selection = {face}
    with pytest.raises(ValueError):
        model.ColorSelection(scene, "#e53935")


@pytest.mark.parametrize("bad", ["red", "#fff", "#12345678", "#rrggbb", None, [], 123])
def test_invalid_color_and_zero_length(colors, bad):
    _, model = colors
    with pytest.raises(ValueError):
        model.make_line(V(0, 0, 0), V(1, 0, 0), bad)
    with pytest.raises(ValueError, match="longitud"):
        model.make_line(V(0, 0, 0), V(0, 0, 0), "#e53935")


def test_nested_transforms_visibility_and_selection(colors):
    _, model = colors
    scene = Scene()
    child = model.make_line(V(0, 0, 1), V(2, 0, 1), "#1e88e5")
    child.xform = QMatrix4x4()
    child.xform.translate(1, 0, 0)
    parent = Group()
    parent.adopt([child])
    parent.xform.translate(0, 3, 0)
    scene.groups.append(parent)
    segments = model.color_segments(scene)
    a, b = segments["#1e88e5"][0]
    assert a == V(1, 3, 1) and b == V(3, 3, 1)
    scene.selection = {parent}
    assert model.color_segments(scene) == {}
    assert model.color_segments(scene, interactive=False) == segments
    scene.selection.clear()
    parent.hidden = True
    assert model.color_segments(scene) == {}
    parent.hidden = False
    scene.layers.append(Layer("Oculta", visible=False))
    parent.layer = "Oculta"
    assert model.color_segments(scene) == {}
    parent.layer = None
    child.mesh.edges[0].hidden = True
    assert model.color_segments(scene) == {}


def test_create_inside_group_and_repeat_undo(colors):
    _, model = colors
    scene = Scene()
    parent = Group()
    parent.adopt([Group()])
    parent.xform.translate(4, 3, 0)
    scene.groups.append(parent)
    scene.begin_group_edit(parent)
    history = History(scene)
    cmd = model.CreateLine(V(4, 3, 1), V(6, 3, 1), "#43a047")
    history.execute(cmd)
    assert cmd.group in parent.children and cmd.group not in scene.groups
    expected = model.color_segments(scene)
    for _ in range(3):
        assert history.undo() and cmd.group not in parent.children
        assert history.redo() and model.color_segments(scene) == expected
    scene.end_group_edit()
    assert model.color_segments(scene) == expected


def test_real_host_setup_native_tool_and_typed_length(color_window, colors, qt_app):
    plugin, model = colors
    assert plugin.__version__ == "0.1.4"
    assert plugin.__plugin_name__ == "JA LineaStyle"
    assert plugin.__license__ == "GPL-3.0-or-later"
    c = controller(color_window)
    assert c.dock.windowTitle() == "LineaStyle"
    assert c.dock.objectName() == "extension_lineas_color"
    from PySide6.QtWidgets import QTabBar
    color_window.show()
    c.app.show_panel(c.dock)
    for _ in range(3):
        qt_app.processEvents()
    tabs = [(bar, index) for bar in color_window.findChildren(QTabBar)
            for index in range(bar.count()) if bar.tabText(index) == "LineaStyle"]
    assert tabs and all(not bar.tabIcon(index).pixmap(16, 16).isNull() for bar, index in tabs)
    assert c.menu_action.text() == "JA LineaStyle…"
    assert c.menu_action.isIconVisibleInMenu()
    assert not c.menu_action.icon().pixmap(16, 16).isNull()
    from PySide6.QtWidgets import QMenu
    context_menu = QMenu()
    c.context_menu(context_menu, {Group()})
    assert not context_menu.actions()[0].icon().pixmap(16, 16).isNull()
    from views.extension_api import ExtensionApp
    assert plugin.setup(ExtensionApp(color_window, "lineas_color")) is c
    assert any(action.text() == "JA LineaStyle…"
               for action in color_window._ext_menu.actions())
    c.draw_button.click()
    vp = color_window.viewport
    before_groups = list(vp.scene.groups)
    assert vp.active_tool is c.tool
    c.choose("#8e24aa")
    c.tool.start_point = V(0, 0, 1)
    c.tool.hover_point = V(1, 0, 1)
    c.tool.chain_vertices = [V(0, 0, 1)]
    assert c.tool.on_value(vp, 2.5)
    assert len(vp.scene.groups) == len(before_groups) + 1
    group = vp.scene.groups[-1]
    assert group.name == "JA LineaStyle"
    assert not group.children and len(group.mesh.edges) == 1
    assert ends(group) == [((0, 0, 1), (2.5, 0, 1))]
    assert model.edge_styles(group)[group.mesh.edges[0]][0] == "#8e24aa"
    assert c.tool.on_undo(vp) and vp.scene.groups == before_groups
    assert vp.history.redo()
    vp.scene.selection = {group}
    c.choose("#43a047")
    c.apply_button.click()
    assert model.group_color(group) == "#43a047"
    assert vp.active_tool is c.tool
    vp.scene.selection = {group}
    command = model.ColorSelection(vp.scene, "#43a047")
    assert not command.changed


def click_line(tool, vp, point, kind="endpoint"):
    tool.on_click(SimpleNamespace(viewport=vp, world=point,
                                 snap=SimpleNamespace(kind=kind)))


def test_one_group_per_tool_activation_even_after_escape_and_style_changes(color_window, colors, tmp_path):
    _, model = colors
    c = controller(color_window)
    vp = color_window.viewport
    vp.scene.groups.clear()
    c.start_drawing()
    assert not vp.scene.groups
    click_line(c.tool, vp, V(0, 0, 1))
    click_line(c.tool, vp, V(2, 0, 1))
    first = vp.scene.groups[0]
    c.tool.on_cancel(vp)
    c.choose("#1e88e5")
    c.width_spin.setValue(5)
    click_line(c.tool, vp, V(0, 1, 1))
    click_line(c.tool, vp, V(3, 1, 1))
    # Pressing the already-selected Draw button restarts only the chain.
    c.draw_button.click()
    click_line(c.tool, vp, V(0, 2, 1))
    click_line(c.tool, vp, V(3, 2, 1))
    assert vp.scene.groups == [first] and len(first.mesh.edges) == 3 and not first.children
    assert model.edge_styles(first)[first.mesh.edges[0]][0] == "#e53935"
    assert model.edge_styles(first)[first.mesh.edges[1]][0] == "#1e88e5"
    assert model.edge_styles(first)[first.mesh.edges[0]][1] == 1
    assert model.edge_styles(first)[first.mesh.edges[1]][1] == 5
    from tools.select import SelectTool
    vp.set_active_tool(SelectTool())
    c.start_drawing()
    click_line(c.tool, vp, V(0, 3, 1))
    click_line(c.tool, vp, V(3, 3, 1))
    second = vp.scene.groups[1]
    assert first is not second and len(second.mesh.edges) == 1 and not second.children
    path = tmp_path / "sessions.igz"
    igz.save_scene(vp.scene, path)
    restored = Scene()
    igz.load_into(restored, path)
    assert [len(g.mesh.edges) for g in restored.groups] == [3, 1]
    assert model.edge_styles(restored.groups[0])[restored.groups[0].mesh.edges[1]][1] == 5
    assert model.edge_styles(restored.groups[0])[restored.groups[0].mesh.edges[1]][0] == "#1e88e5"


def test_session_segment_undo_redo_closure_and_document_boundary(color_window):
    c = controller(color_window)
    vp = color_window.viewport
    vp.scene.groups.clear()
    c.start_drawing()
    click_line(c.tool, vp, V(0, 0, 0))
    click_line(c.tool, vp, V(2, 0, 0))
    click_line(c.tool, vp, V(2, 2, 0))
    click_line(c.tool, vp, V(0, 0, 0), kind="close")
    group = vp.scene.groups[0]
    assert len(group.mesh.edges) == 3 and len(group.mesh.faces) == 1 and not group.children
    assert len(group.mesh.vertices) == 3
    assert all(e.faces == group.mesh.faces for e in group.mesh.edges)
    for _ in range(2):
        for remaining in (2, 1, 0):
            assert vp.history.undo()
            assert len(group.mesh.edges) == remaining
            assert not group.mesh.faces
        assert not vp.scene.groups
        for count in (1, 2, 3):
            assert vp.history.redo()
            assert vp.scene.groups == [group] and len(group.mesh.edges) == count
            assert len(group.mesh.faces) == (1 if count == 3 else 0)
    # Cancel and begin a disconnected run without changing the group.
    c.tool.on_cancel(vp)
    click_line(c.tool, vp, V(4, 0, 0))
    click_line(c.tool, vp, V(5, 0, 0))
    assert vp.scene.groups == [group] and len(group.mesh.edges) == 4
    # New/Open clears the scene and history even if the tool stays selected.
    vp.scene.groups.clear()
    vp.history.clear()
    c.tool.on_cancel(vp)
    click_line(c.tool, vp, V(8, 0, 0))
    click_line(c.tool, vp, V(9, 0, 0))
    assert len(vp.scene.groups) == 1 and vp.scene.groups[0] is not group
    assert len(group.mesh.edges) == 4


def test_drawing_after_undoing_all_segments_reuses_session(color_window):
    c = controller(color_window)
    vp = color_window.viewport
    vp.scene.groups.clear()
    c.start_drawing()
    click_line(c.tool, vp, V(0, 0, 0))
    click_line(c.tool, vp, V(2, 0, 0))
    group = vp.scene.groups[0]
    assert c.tool.on_undo(vp) and not vp.scene.groups
    click_line(c.tool, vp, V(0, 2, 0))
    assert vp.scene.groups == [group] and len(group.mesh.edges) == 1
    assert not vp.history.redo_stack


def test_width_changes_undo_save_copy_and_legacy_documents(colors, tmp_path):
    _, model = colors
    scene = Scene()
    group = model.make_line(V(0, 0, 1), V(3, 0, 1), "#e53935", width_px=6)
    scene.groups.append(group)
    scene.selection = {group}
    history = History(scene)
    cmd = model.ColorSelection(scene, "#e53935", width_px=3)
    assert cmd.changed
    history.execute(cmd)
    assert model.group_width(group) == 3
    assert history.undo() and model.group_width(group) == 6
    assert history.redo() and model.group_width(group) == 3
    copied = copy_group(group, V(0, 1, 0))
    assert model.group_width(copied) == 3
    scene.groups.append(copied)
    path = tmp_path / "widths.igz"
    igz.save_scene(scene, path)
    restored = Scene()
    igz.load_into(restored, path)
    assert [model.group_width(g) for g in restored.groups] == [3, 3]
    group.ext[model.KEY].pop("width_px")
    assert model.group_width(group) == 1
    scene.selection = {group}
    history.execute(model.ColorSelection(scene, None))
    assert group.ext is None and model.group_width(group) == 1


def test_context_color_preserves_width_and_panel_apply_changes_both(color_window, colors):
    _, model = colors
    c = controller(color_window)
    vp = color_window.viewport
    group = model.make_line(V(0, 0, 1), V(3, 0, 1), "#e53935", width_px=6)
    vp.scene.groups.append(group)
    vp.scene.selection = {group}
    c.apply_color("#1e88e5")
    assert model.group_color(group) == "#1e88e5" and model.group_width(group) == 6
    vp.scene.selection = {group}
    c.width_spin.setValue(3)
    c.apply_button.click()
    assert model.group_color(group) == "#1e88e5" and model.group_width(group) == 3


@pytest.mark.parametrize("bad", [True, "3", 0, -1, 12.5, float("nan"), float("inf")])
def test_reject_invalid_width_before_mutation(colors, bad):
    _, model = colors
    scene = Scene()
    group = model.make_line(V(0, 0, 0), V(1, 0, 0), "#e53935")
    scene.groups.append(group)
    scene.selection = {group}
    with pytest.raises(ValueError, match="grosor"):
        model.ColorSelection(scene, "#1e88e5", width_px=bad)
    assert model.group_color(group) == "#e53935" and model.group_width(group) == 1


def test_session_inside_transformed_parent_and_copy(color_window, colors):
    _, model = colors
    vp = color_window.viewport
    vp.scene.groups.clear()
    parent = Group()
    parent.adopt([Group()])
    parent.xform.translate(4, 3, 0)
    vp.scene.groups.append(parent)
    vp.scene.begin_group_edit(parent)
    c = controller(color_window)
    c.start_drawing()
    click_line(c.tool, vp, V(4, 3, 1))
    click_line(c.tool, vp, V(6, 3, 1))
    click_line(c.tool, vp, V(6, 4, 1))
    container = parent.children[-1]
    assert len(container.mesh.edges) == 2 and not container.children and container not in vp.scene.groups
    expected = model.color_segments(vp.scene)
    assert expected["#e53935"][0] == (V(4, 3, 1), V(6, 3, 1))
    assert vp.history.undo() and len(container.mesh.edges) == 1
    assert vp.history.redo() and model.color_segments(vp.scene) == expected
    vp.scene.end_group_edit()
    assert model.color_segments(vp.scene) == expected
    copied = copy_group(container, V(0, 2, 0))
    assert len(copied.mesh.edges) == 2 and not copied.children
    assert model.edge_styles(copied)[copied.mesh.edges[0]][0] == "#e53935"


def test_gl_line_width_selection_and_preview(color_window, colors, qt_app):
    _, model = colors
    color_window.show()
    for _ in range(10):
        qt_app.processEvents()
    vp = color_window.viewport
    if not vp.isValid() or vp._gl is None:
        pytest.skip("This Qt platform has no OpenGL widget; use cocoa for render verification.")
    scene = vp.scene
    scene.mesh.clear()
    scene.groups.clear()
    scene.groups.extend([
        model.make_line(V(-2, -1, 0.7), V(2, -1, 0.7), "#e53935", width_px=1),
        model.make_line(V(-2, -1, 1.3), V(2, -1, 1.3), "#1e88e5", width_px=6),
    ])
    scene.display_style.face_mode = "hidden_line"
    scene.display_style.sky = False
    vp.camera.set_view("front")
    vp.camera.perspective = False
    vp.camera.fit_to(V(-2.4, -1, 0), V(2.4, 1, 2))
    scene.version += 1
    vp.notify_scene_changed()
    for _ in range(5):
        qt_app.processEvents()

    def count(image, point, predicate):
        px, py = vp._world_to_pixel(point)
        x = round(px * image.width() / vp.width())
        y = round(py * image.height() / vp.height())
        return sum(predicate(image.pixelColor(x, y + dy)) for dy in range(-25, 26))

    red = lambda c: c.redF() > c.greenF() + 0.2 and c.redF() > c.blueF() + 0.2
    blue = lambda c: c.blueF() > c.redF() + 0.2 and c.blueF() > c.greenF() + 0.1
    green = lambda c: c.greenF() > c.redF() + 0.15 and c.greenF() > c.blueF() + 0.15
    orange = lambda c: c.redF() > c.greenF() + 0.2 and c.greenF() > c.blueF() + 0.15
    image = vp.render_image(1200, overlays=False)
    thin = count(image, V(1, -1, 0.7), red)
    thick = count(image, V(1, -1, 1.3), blue)
    assert thin > 0 and thick >= thin + 4
    # Selected lines remain thick in the native orange highlight.
    scene.select([scene.groups[1]])
    vp.notify_scene_changed()
    live = vp.grabFramebuffer()
    assert count(live, V(1, -1, 1.3), orange) >= 4
    scene.clear_selection()
    c = controller(color_window)
    c.choose("#43a047")
    c.width_spin.setValue(8)
    c.start_drawing()
    c.tool.start_point, c.tool.hover_point = V(-2, -1, 1), V(2, -1, 1)
    live = vp.grabFramebuffer()
    assert count(live, V(1, -1, 1), green) >= 6
    # The pending preview is excluded from a saved raster image.
    image = vp.render_image(1200, overlays=False)
    assert count(image, V(1, -1, 1), green) == 0
    assert not c.renderer.failed


def test_gl_colors_and_depth(color_window, colors, qt_app, tmp_path):
    """Run with QT_QPA_PLATFORM=cocoa on macOS to verify actual pixels."""
    _, model = colors
    color_window.show()
    for _ in range(10):
        qt_app.processEvents()
    vp = color_window.viewport
    if not vp.isValid() or vp._gl is None:
        pytest.skip("This Qt platform has no OpenGL widget; use cocoa for render verification.")
    scene = vp.scene
    scene.mesh.clear()
    scene.groups.clear()
    scene.mesh.add_face([V(-1, 0, 0), V(1, 0, 0), V(1, 0, 2), V(-1, 0, 2)])
    scene.groups.extend([
        model.make_line(V(-3, 1, 1), V(3, 1, 1), "#e53935"),
        model.make_line(V(-3, -1, 0.4), V(3, -1, 0.4), "#43a047"),
        model.make_line(V(-3, -1, 1.6), V(3, -1, 1.6), "#1e88e5"),
    ])
    scene.display_style.face_mode = "hidden_line"
    scene.display_style.sky = False
    scene.display_style.profiles = False
    vp.camera.set_view("front")
    vp.camera.perspective = False
    vp.camera.fit_to(V(-3.2, -1, 0), V(3.2, 1, 2))
    scene.version += 1
    vp.notify_scene_changed()
    for _ in range(5):
        qt_app.processEvents()
    image = vp.render_image(1200, overlays=False)
    assert image is not None and not image.isNull()
    assert not controller(color_window).renderer.failed
    image.save(str(tmp_path / "color_lines.png"))

    def sample(point):
        px, py = vp._world_to_pixel(point)
        x, y = int(px * image.width() / vp.width()), int(py * image.height() / vp.height())
        return [image.pixelColor(x + dx, y + dy) for dx in range(-3, 4) for dy in range(-3, 4)]

    red = lambda c: c.redF() > c.greenF() + 0.2 and c.redF() > c.blueF() + 0.2
    green = lambda c: c.greenF() > c.redF() + 0.15 and c.greenF() > c.blueF() + 0.15
    blue = lambda c: c.blueF() > c.redF() + 0.2 and c.blueF() > c.greenF() + 0.1
    assert any(red(c) for c in sample(V(2, 1, 1)))
    assert not any(red(c) for c in sample(V(0.4, 1, 1)))
    assert any(green(c) for c in sample(V(0.4, -1, 0.4)))
    assert any(blue(c) for c in sample(V(0.4, -1, 1.6)))
    # Cut away x > 0: the colour pass must use the same 3D clipping plane.
    from core.section import SectionPlane
    scene.section_planes.append(SectionPlane(V(0, 0, 0), V(1, 0, 0), active=True))
    scene.version += 1
    image = vp.render_image(1200, overlays=False)
    assert not any(green(c) for c in sample(V(2, -1, 0.4)))
    assert any(green(c) for c in sample(V(-2, -1, 0.4)))


def test_shared_plane_crossings_and_individual_styles(color_window, colors, tmp_path):
    _, model = colors
    c, vp = controller(color_window), color_window.viewport
    vp.scene.groups.clear()
    c.start_drawing()
    points = [V(0, 0, 1), V(4, 0, 1), V(4, 4, 1), V(0, 4, 1), V(0, 0, 1)]
    click_line(c.tool, vp, points[0])
    for i, point in enumerate(points[1:]):
        c.pattern_combo.setCurrentIndex(i + 1)
        c.width_spin.setValue(i + 2)
        click_line(c.tool, vp, point, "close" if i == 3 else "endpoint")
    group = vp.scene.groups[0]
    assert not group.children and len(group.mesh.vertices) == 4
    assert len(group.mesh.faces) == 1 and len(group.mesh.edges) == 4
    original = model.edge_styles(group)
    assert {s[2] for s in original.values()} == {"dotted", "dashed", "long_dash", "dash_dot"}
    # A line crossing the shared plane divides it into two genuine faces.
    c.choose("#1e88e5")
    c.pattern_combo.setCurrentIndex(5)
    click_line(c.tool, vp, V(0, 2, 1))
    click_line(c.tool, vp, V(4, 2, 1))
    assert not vp.history.last_error
    assert len(group.mesh.faces) == 2 and len(group.mesh.edges) == 7
    styles = model.edge_styles(group)
    crossing = [e for e in group.mesh.edges if e.a.y() == e.b.y() == 2]
    assert len(crossing) == 1 and styles[crossing[0]][2] == "dash_dot_dot"
    # The split sides keep the styles of the original, differently styled edges.
    assert sorted(s[2] for s in styles.values()) == sorted([
        "dotted", "dashed", "dashed", "long_dash", "dash_dot", "dash_dot", "dash_dot_dot"])
    assert vp.history.undo() and len(group.mesh.faces) == 1
    assert model.edge_styles(group) == original
    assert vp.history.redo() and len(group.mesh.faces) == 2
    path = tmp_path / "plane.igz"
    igz.save_scene(vp.scene, path)
    restored = Scene()
    igz.load_into(restored, path)
    saved = restored.groups[0]
    assert not saved.children and len(saved.mesh.faces) == 2
    assert sorted(model.edge_styles(saved).values()) == sorted(styles.values())


def test_open_global_group_extends_plane_without_creating_children(color_window, colors, tmp_path):
    _, model = colors
    c, vp = controller(color_window), color_window.viewport
    vp.scene.groups.clear()
    c.start_drawing()
    click_line(c.tool, vp, V(0, 0, 1))
    click_line(c.tool, vp, V(4, 0, 1))
    c.pattern_combo.setCurrentIndex(4)
    click_line(c.tool, vp, V(4, 4, 1))
    click_line(c.tool, vp, V(0, 0, 1), "close")
    group = vp.scene.groups[0]
    before_styles = sorted(model.edge_styles(group).values())
    vp.history.execute(MoveGroupCommand(group, V(3, 2, 0)))
    vp.scene.begin_group_edit(group)
    assert sorted(model.edge_styles(group).values()) == before_styles
    c.start_drawing()
    click_line(c.tool, vp, V(3, 2, 1))
    click_line(c.tool, vp, V(7, 6, 1))
    assert vp.scene.groups == [group] and not group.children
    assert len(group.mesh.edges) == 3  # Drawing over the existing diagonal welds it.
    selected = group.mesh.edges[0]
    vp.scene.selection = {selected}
    c.choose("#43a047")
    c.width_spin.setValue(8)
    c.pattern_combo.setCurrentIndex(5)
    c.apply_button.click()
    assert model.edge_styles(group)[selected] == ("#43a047", 8, "dash_dot_dot")
    assert len(group.mesh.faces) == 1 and not vp.history.last_error
    assert vp.history.undo()
    assert model.edge_styles(group)[selected][0] == "#e53935"
    assert vp.history.redo()
    vp.scene.end_group_edit()
    copied = copy_group(group, V(0, 5, 0))
    vp.scene.groups.append(copied)
    assert sorted(model.edge_styles(copied).values()) == sorted(model.edge_styles(group).values())
    path = tmp_path / "edited-plane.igz"
    igz.save_scene(vp.scene, path)
    restored = Scene()
    igz.load_into(restored, path)
    assert sorted(model.edge_styles(restored.groups[0]).values()) == sorted(model.edge_styles(group).values())
    assert sorted(model.edge_styles(restored.groups[1]).values()) == sorted(model.edge_styles(group).values())


@pytest.mark.parametrize("pattern", ["solid", "dotted", "dashed", "long_dash", "dash_dot", "dash_dot_dot"])
def test_pattern_apply_undo_copy_save_and_legacy(colors, tmp_path, pattern):
    _, model = colors
    scene = Scene()
    group = model.make_line(V(0, 0, 1), V(3, 0, 1), "#e53935", width_px=4)
    scene.groups.append(group)
    scene.selection = {group}
    history = History(scene)
    history.execute(model.ColorSelection(scene, "#1e88e5", pattern=pattern))
    assert model.group_pattern(group) == pattern and model.group_width(group) == 4
    assert history.undo() and model.group_pattern(group) == "solid"
    assert history.redo() and model.group_pattern(group) == pattern
    copied = copy_group(group, V(0, 1, 0))
    scene.groups.append(copied)
    path = tmp_path / "patterns.igz"
    igz.save_scene(scene, path)
    restored = Scene()
    igz.load_into(restored, path)
    assert [model.group_pattern(g) for g in restored.groups] == [pattern] * 2
    group.ext[model.KEY].pop("pattern")
    assert model.group_pattern(group) == "solid"


@pytest.mark.parametrize("bad", [None, "unknown", "", [], 1])
def test_invalid_pattern_before_mutation(colors, bad):
    _, model = colors
    with pytest.raises(ValueError, match="estilo"):
        model.make_line(V(0, 0, 0), V(1, 0, 0), "#e53935", pattern=bad)


def test_gl_patterns_have_real_gaps_and_preserve_native_geometry(color_window, colors, qt_app):
    _, model = colors
    color_window.show()
    for _ in range(10):
        qt_app.processEvents()
    vp, c = color_window.viewport, controller(color_window)
    if not vp.isValid() or vp._gl is None:
        pytest.skip("Use cocoa to verify actual OpenGL pattern pixels.")
    vp.scene.groups.clear()
    vp.scene.mesh.clear()
    group = model.make_line(V(-2, -1, 2), V(2, -1, 2), "#e53935", width_px=3)
    group.xform = QMatrix4x4()  # Exercise the normally instanced path as well.
    vp.scene.groups.append(group)
    style = vp.scene.display_style
    style.face_mode, style.sky, style.profiles = "hidden_line", False, False
    style.background = (1, 1, 1)
    vp.camera.set_view("front")
    vp.camera.perspective = False
    vp.camera.fit_to(V(-2.4, -1, 1), V(2.4, 1, 3))

    def coverage(image):
        p0, p1 = [vp._world_to_pixel(p) for p in (V(-1.8, -1, 2), V(1.8, -1, 2))]
        xs = sorted(round(p[0] * image.width() / vp.width()) for p in (p0, p1))
        y = round(p0[1] * image.height() / vp.height())
        occupied = [any(image.pixelColor(x, y + dy).lightnessF() < 0.75 for dy in (-1, 0, 1))
                    for x in range(xs[0], xs[1])]
        return sum(occupied) / len(occupied)

    fractions = {}
    for key in ("solid", "dotted", "dashed", "long_dash", "dash_dot", "dash_dot_dot"):
        model.set_color(group, "#e53935", 3, key)
        vp.scene.version += 1
        vp.notify_scene_changed()
        image = vp.render_image(1200, overlays=False)
        assert not c.renderer.failed
        fractions[key] = coverage(image)
        assert len(group.mesh.edges) == 1 and len(group.mesh.vertices) == 2
    assert fractions["solid"] > 0.95
    assert all(0.15 < fraction < 0.90 for key, fraction in fractions.items() if key != "solid")
    # Native selection highlights and hover must not fill the gaps.
    vp.scene.select([group])
    vp._hover_entity = group.mesh.edges[0]
    vp.notify_scene_changed()
    assert 0.15 < coverage(vp.grabFramebuffer()) < 0.90
    vp.scene.clear_selection()
    vp._hover_entity = None
    # Resetting the group restores the native solid render buffers.
    model.set_color(group, None)
    vp.scene.version += 1
    vp.notify_scene_changed()
    assert coverage(vp.render_image(1200, overlays=False)) > 0.95


def test_legacy_session_unifies_into_shared_mesh_and_undo_restores_subgroups(color_window, colors):
    _, model = colors
    vp, c = color_window.viewport, controller(color_window)
    vp.scene.groups.clear()
    old = Group(name="Líneas de colores")
    points = [V(0, 0, 1), V(3, 0, 1), V(3, 3, 1), V(0, 0, 1)]
    children = [model.make_line(a, b, color, width_px=i + 2)
                for i, (a, b, color) in enumerate(zip(points, points[1:],
                                                      ("#e53935", "#43a047", "#1e88e5")))]
    old.adopt(children)
    old.xform.translate(2, 4, 0)
    vp.scene.groups.append(old)
    vp.scene.begin_group_edit(old)
    c.start_drawing()
    click_line(c.tool, vp, V(2, 4, 1))
    click_line(c.tool, vp, V(2, 6, 1))
    assert vp.scene.groups == [old] and not old.children
    assert len(old.mesh.faces) == 1 and len(old.mesh.edges) == 4
    assert set(model.color_segments(vp.scene)) == {"#e53935", "#43a047", "#1e88e5"}
    assert vp.history.undo() and old.children == children and not old.mesh.edges
    assert vp.history.redo() and not old.children and len(old.mesh.faces) == 1


def test_native_vertex_move_and_edge_erase_keep_per_edge_styles(color_window, colors, tmp_path):
    _, model = colors
    vp, c = color_window.viewport, controller(color_window)
    vp.scene.groups.clear()
    c.start_drawing()
    click_line(c.tool, vp, V(0, 0, 1))
    click_line(c.tool, vp, V(3, 0, 1))
    c.choose("#1e88e5")
    c.pattern_combo.setCurrentIndex(4)
    click_line(c.tool, vp, V(3, 3, 1))
    group = vp.scene.groups[0]
    vp.scene.begin_group_edit(group)
    first, second = group.mesh.edges
    group.mesh.move_vertex(first.v0, V(-1, 0, 0))
    vp.scene.version += 1
    vp.notify_scene_changed()
    from core.history import DeleteEdgesCommand
    vp.history.execute(DeleteEdgesCommand([first]))
    vp.notify_scene_changed()
    assert model.edge_styles(group)[second] == ("#1e88e5", 1, "dash_dot")
    assert vp.history.undo()
    assert model.edge_styles(group)[first] == ("#e53935", 1, "solid")
    vp.scene.end_group_edit()
    path = tmp_path / "native-edit.igz"
    igz.save_scene(vp.scene, path)
    restored = Scene()
    igz.load_into(restored, path)
    assert sorted(model.edge_styles(restored.groups[0]).values()) == sorted(model.edge_styles(group).values())


@pytest.mark.parametrize("color", ["#e53935", "#1e88e5", "#20252b", "#ffffff", "#dc37af"])
@pytest.mark.parametrize("dpr", [1, 2])
def test_colored_pencil_cursor_tip_and_display_scale(colors, color, dpr):
    from importlib import import_module
    from PySide6.QtCore import QPoint, Qt
    from PySide6.QtGui import QColor
    cursor_module = import_module(colors[0].__name__ + ".cursor")
    cursor = cursor_module.pencil_cursor(color, dpr)
    assert cursor.shape() == Qt.CursorShape.BitmapCursor
    assert cursor.hotSpot() == QPoint(4, 28)
    pixmap = cursor.pixmap()
    assert pixmap.width() == pixmap.height() == 32 * dpr
    assert pixmap.devicePixelRatio() == dpr
    image = pixmap.toImage()
    center = image.pixelColor(16 * dpr, 16 * dpr)
    expected = QColor(color)
    assert center.alpha() == 255
    assert max(abs(center.red() - expected.red()), abs(center.green() - expected.green()),
               abs(center.blue() - expected.blue())) < 8
    assert image.pixelColor(4 * dpr, 28 * dpr).alpha() > 0
    assert image.pixelColor(0, 0).alpha() == 0


def test_native_pencil_cursor_changes_color_and_restores_other_tools(color_window):
    from PySide6.QtCore import QPoint, Qt
    from PySide6.QtGui import QColor
    from tools.select import SelectTool
    c, vp = controller(color_window), color_window.viewport

    def pencil_matches(color):
        assert vp.cursor().shape() == Qt.CursorShape.BitmapCursor
        assert vp.cursor().hotSpot() == QPoint(4, 28)
        pixmap = vp.cursor().pixmap()
        dpr = pixmap.devicePixelRatio()
        center = pixmap.toImage().pixelColor(round(16 * dpr), round(16 * dpr))
        expected = QColor(color)
        assert max(abs(center.red() - expected.red()), abs(center.green() - expected.green()),
                   abs(center.blue() - expected.blue())) < 8

    c.start_drawing()
    pencil_matches("#e53935")
    for color in ("#1e88e5", "#ffffff", "#20252b", "#dc37af"):
        c.choose(color)
        pencil_matches(color)
        # Same native recovery used on re-entry from the colour panel and
        # after committing/cancelling a segment, including Windows resets.
        vp._reassert_tool_cursor()
        pencil_matches(color)
    c.tool.on_cancel(vp)
    c.draw_button.click()
    pencil_matches("#dc37af")
    vp.set_active_tool(SelectTool())
    assert vp.cursor().shape() == Qt.CursorShape.ArrowCursor
    c.choose("#43a047")
    assert vp.cursor().shape() == Qt.CursorShape.ArrowCursor
    c.start_drawing()
    pencil_matches("#43a047")


def test_pencil_respects_temporary_camera_cursor(color_window):
    from PySide6.QtCore import QPoint, Qt
    c, vp = controller(color_window), color_window.viewport
    c.start_drawing()
    # The host temporarily replaces the tool cursor during a wheel drag.
    vp._last_pos = QPoint(10, 10)
    vp.setCursor(Qt.CursorShape.OpenHandCursor)
    c.choose("#1e88e5")
    assert vp.cursor().shape() == Qt.CursorShape.OpenHandCursor
    vp._end_camera_drag()
    assert vp.cursor().shape() == Qt.CursorShape.BitmapCursor
    assert vp.cursor().hotSpot() == QPoint(4, 28)
    # Choosing a camera tool deactivates drawing altogether.
    vp.set_nav_mode("pan")
    previous = vp.cursor().pixmap().cacheKey()
    c.choose("#e53935")
    assert vp.active_tool is None and vp.nav_mode == "pan"
    assert vp.cursor().pixmap().cacheKey() == previous


def reference_view(window):
    """A real viewport with a predictable pixel projection, without GL."""
    vp = window.viewport
    vp.scene.groups.clear()
    vp.scene.mesh.clear()
    vp.scene.guides.clear()
    vp.resize(900, 650)
    vp.camera.set_aspect(vp.width(), vp.height())
    vp.camera.perspective = False
    vp.camera.set_view("front")
    vp.camera.fit_to(V(-2, -1, -1), V(8, 1, 6))
    vp.scene.version += 1
    vp.notify_scene_changed()
    return vp, controller(window)


def hover_world(vp, point):
    from PySide6.QtCore import QPointF, Qt
    pixel = vp._world_to_pixel(point)
    assert pixel is not None
    vp._process_hover(QPointF(*pixel), Qt.KeyboardModifier.NoModifier)
    return vp.last_snap


def click_world(vp, point):
    from PySide6.QtCore import QPointF, Qt
    from views.viewport import _HoverEvent
    hover_world(vp, point)
    vp._dispatch_tool_click(_HoverEvent(QPointF(*vp._world_to_pixel(point)),
                                       Qt.KeyboardModifier.NoModifier))


@pytest.mark.parametrize("pattern", ["solid", "dotted", "dashed", "long_dash", "dash_dot", "dash_dot_dot"])
def test_styled_line_endpoint_midpoint_and_on_edge_references(color_window, colors, pattern):
    _, model = colors
    vp, c = reference_view(color_window)
    group = model.make_line(V(1, 0, 1), V(5, 0, 1), "#e53935", width_px=4, pattern=pattern)
    vp.scene.groups.append(group)
    vp.scene.version += 1
    vp.notify_scene_changed()
    c.start_drawing()
    # The visual draw buffer stays filtered; picking must see its native edges.
    assert vp._group_chunk(group)["edges"] == b""
    for point, kind in ((V(1, 0, 1), "endpoint"), (V(3, 0, 1), "midpoint"),
                        (V(2, 0, 1), "on_edge")):
        snap = hover_world(vp, point)
        assert snap.kind == kind
        assert (snap.point - point).length() < 0.03
        assert vp._hover_edge is not None
        assert vp._group_chunk(group)["edges"] == b""


def test_drawn_lines_remain_references_and_close_a_native_face(color_window):
    vp, c = reference_view(color_window)
    c.start_drawing()
    a, b = V(1, 0, 1), V(5, 0, 1)
    click_line(c.tool, vp, a)
    click_line(c.tool, vp, b)
    group = c.tool.session.group
    c.tool.on_cancel(vp)
    assert hover_world(vp, (a + b) * 0.5).kind == "midpoint"
    click_world(vp, a)
    assert c.tool.start_point == a
    click_world(vp, V(3, 0, 4))
    assert hover_world(vp, b).kind == "endpoint"
    click_world(vp, b)
    assert vp.scene.groups == [group] and not group.children
    assert len(group.mesh.edges) == 3 and len(group.mesh.faces) == 1
    assert vp.history.undo() and not group.mesh.faces
    assert hover_world(vp, b).kind == "endpoint"
    assert vp.history.redo() and len(group.mesh.faces) == 1


def test_nested_transformed_line_can_be_referenced_and_selected(color_window, colors):
    _, model = colors
    vp, c = reference_view(color_window)
    child = model.make_line(V(0, 0, 0), V(3, 0, 0), "#1e88e5", pattern="dashed")
    child.xform = QMatrix4x4()
    child.xform.translate(1, 0, 0.5)
    parent = Group(name="Referencia girada")
    parent.adopt([child])
    parent.xform = QMatrix4x4()
    parent.xform.translate(1, 1, 2)
    parent.xform.rotate(23, 0, 1, 0)
    vp.scene.groups.append(parent)
    vp.scene.version += 1
    vp.notify_scene_changed()
    c.start_drawing()
    a = parent.xform.map(child.xform.map(child.mesh.edges[0].a))
    b = parent.xform.map(child.xform.map(child.mesh.edges[0].b))
    for point, kind in ((b, "endpoint"), ((a + b) * 0.5, "midpoint")):
        snap = hover_world(vp, point)
        assert snap.kind == kind and (snap.point - point).length() < 1e-5
    pixel = vp._world_to_pixel((a + b) * 0.5)
    assert vp.pick_group(*pixel) is parent


def test_native_and_styled_edges_offer_exact_crossing_reference(color_window, colors):
    _, model = colors
    vp, c = reference_view(color_window)
    vp.scene.groups.append(model.make_line(V(1, 0, 1), V(5, 0, 1), "#43a047", pattern="dotted"))
    vp.scene.mesh.add_edge(V(3, 0, -1), V(3, 0, 3))
    vp.scene.version += 1
    vp.notify_scene_changed()
    c.start_drawing()
    snap = hover_world(vp, V(3, 0, 1))
    assert snap.kind == "intersection" and snap.point == V(3, 0, 1)
    assert hover_world(vp, V(3, 0, 3)).kind == "endpoint"


def test_down_arrow_captures_styled_edge_parallel_and_perpendicular(color_window, colors):
    from PySide6.QtCore import QEvent, Qt
    from PySide6.QtGui import QKeyEvent
    _, model = colors
    vp, c = reference_view(color_window)
    vp.scene.groups.append(model.make_line(V(1, 0, 1), V(5, 0, 1), "#e53935", pattern="dash_dot"))
    vp.scene.version += 1
    vp.notify_scene_changed()
    c.start_drawing()
    click_line(c.tool, vp, V(0, 0, 4))
    hover_world(vp, V(2, 0, 1))
    assert vp._hover_edge is not None
    down = lambda: vp.keyPressEvent(QKeyEvent(QEvent.Type.KeyPress, Qt.Key.Key_Down,
                                             Qt.KeyboardModifier.NoModifier))
    down()
    assert vp.reference_mode == "parallel"
    snap = hover_world(vp, V(4, 0, 4.3))
    assert snap.kind == "reference" and abs(snap.point.z() - 4) < 1e-6
    down()
    assert vp.reference_mode == "perpendicular"
    snap = hover_world(vp, V(0.3, 0, 2))
    assert snap.kind == "reference" and abs(snap.point.x()) < 1e-6
    down()
    assert vp.reference_mode is None and vp.reference_edge is None


def test_open_group_keeps_external_line_references_until_surroundings_hidden(color_window, colors):
    _, model = colors
    vp, c = reference_view(color_window)
    own = model.make_line(V(1, 0, 4), V(5, 0, 4), "#1e88e5")
    external = model.make_line(V(1, 0, 1), V(5, 0, 1), "#43a047", pattern="dashed")
    vp.scene.groups.extend([own, external])
    vp.scene.begin_group_edit(own)
    vp.set_edit_rest_mode("fade")
    vp.scene.version += 1
    vp.notify_scene_changed()
    c.start_drawing()
    snap = hover_world(vp, V(1, 0, 1))
    assert snap.kind == "endpoint" and snap.point == V(1, 0, 1)
    vp.set_edit_rest_mode("hide")
    snap = hover_world(vp, V(1, 0, 1))
    assert snap.kind not in ("endpoint", "midpoint", "on_edge")


@pytest.mark.parametrize("hidden", ["group", "edge"])
def test_hidden_styled_geometry_does_not_attract_references(color_window, colors, hidden):
    _, model = colors
    vp, c = reference_view(color_window)
    group = model.make_line(V(1, 0, 1), V(5, 0, 1), "#e53935", pattern="dotted")
    if hidden == "group":
        group.hidden = True
    else:
        group.mesh.edges[0].hidden = True
    vp.scene.groups.append(group)
    vp.scene.version += 1
    vp.notify_scene_changed()
    c.start_drawing()
    assert hover_world(vp, V(1, 0, 1)).kind not in ("endpoint", "midpoint", "on_edge")


@pytest.fixture(params=["legacy", "near"])
def pick_api_window(colors, monkeypatch, request):
    from core import extensions
    from views.main_window import MainWindow
    from views.viewport import Viewport
    original = Viewport._pick_index
    if request.param == "legacy":
        # Same public signature as the actual shipped macOS 0.5.7 binary.
        def legacy_pick(self):
            return original(self)
        monkeypatch.setattr(Viewport, "_pick_index", legacy_pick)
    monkeypatch.setattr(extensions, "plugin_dirs", lambda: [PROJECT])
    window = MainWindow()
    window._autosave_timer.stop()
    yield window
    window.hide()
    window.deleteLater()


def test_startup_camera_and_styled_drawing_with_both_pick_apis(pick_api_window, colors):
    from PySide6.QtCore import QEvent, QPoint, QPointF, Qt
    from PySide6.QtGui import QMouseEvent, QWheelEvent
    _, model = colors
    vp, c = reference_view(pick_api_window)
    vp.scene.groups.append(model.make_line(V(1, 0, 1), V(5, 0, 1), "#1e88e5", pattern="dashed"))
    vp.scene.version += 1
    vp.notify_scene_changed()
    # Startup/Select reads picking before LineaStyle has ever been activated.
    assert vp._pick_index().gedge_a is not None
    center = QPointF(vp.rect().center())

    def event(kind, point, button, buttons, modifiers=Qt.NoModifier):
        return QMouseEvent(kind, point, button, buttons, modifiers)

    for modifiers in (Qt.NoModifier, Qt.ShiftModifier):
        before = (vp.camera.yaw, vp.camera.pitch, V(vp.camera.target))
        vp.mousePressEvent(event(QEvent.MouseButtonPress, center, Qt.MiddleButton, Qt.MiddleButton, modifiers))
        vp.mouseMoveEvent(event(QEvent.MouseMove, center + QPointF(40, 20), Qt.NoButton, Qt.MiddleButton, modifiers))
        vp.mouseReleaseEvent(event(QEvent.MouseButtonRelease, center + QPointF(40, 20), Qt.MiddleButton, Qt.NoButton, modifiers))
        assert before != (vp.camera.yaw, vp.camera.pitch, vp.camera.target)
    distance = vp.camera.distance
    vp.wheelEvent(QWheelEvent(center, center, QPoint(0, 0), QPoint(0, 120),
                             Qt.NoButton, Qt.NoModifier, Qt.NoScrollPhase, False))
    assert vp.camera.distance != distance
    vp.camera.set_view("front")
    vp.camera.fit_to(V(-2, -1, -1), V(8, 1, 6))
    c.start_drawing()
    assert hover_world(vp, V(3, 0, 1)).kind == "midpoint"
    click_world(vp, V(1, 0, 1))
    click_world(vp, V(3, 0, 4))
    click_world(vp, V(5, 0, 1))
    group = c.tool.session.group
    assert len(group.mesh.edges) == 2 and vp.history.last_error is None
    assert vp.history.undo() and len(group.mesh.edges) == 1
    assert vp.history.redo() and len(group.mesh.edges) == 2
