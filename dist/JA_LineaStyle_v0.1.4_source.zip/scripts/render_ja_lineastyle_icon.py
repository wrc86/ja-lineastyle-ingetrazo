# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Julio Angulo
"""Render the editable SVG into portable native-menu PNG sizes."""
from pathlib import Path
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6.QtCore import Qt
from PySide6.QtGui import QImage, QPainter
from PySide6.QtSvg import QSvgRenderer

ROOT = Path(__file__).resolve().parents[1]
ICONS = ROOT / "JA_LineaStyle_IngeTrazo" / "lineas_color" / "icons"


def render():
    renderer = QSvgRenderer(str(ICONS / "ja_lineastyle.svg"))
    if not renderer.isValid():
        raise ValueError("El icono SVG no es válido.")
    for size in (16, 32, 64, 128):
        image = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.transparent)
        painter = QPainter(image)
        renderer.render(painter)
        painter.end()
        path = ICONS / f"ja_lineastyle_{size}.png"
        if not image.save(str(path)):
            raise RuntimeError(f"No se pudo guardar {path.name}.")
        print(path.name)


if __name__ == "__main__":
    render()
