# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Julio Angulo
"""Exercise the installed macOS application in a disposable plugin profile.

Starts a separate --new-window process, never the user's open document.
The probe exits that process without saving its window layout or document.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]

PROBE = r'''
import faulthandler
import inspect
import json
import os
from pathlib import Path
import sys
import traceback
from PySide6.QtCore import QEvent, QPoint, QPointF, QSettings, QTimer, Qt
from PySide6.QtGui import QMouseEvent, QWheelEvent, QVector3D as V
from PySide6.QtWidgets import QAbstractButton, QApplication

folder = Path(os.environ["JA_LINEASTYLE_PROBE_DIR"])
log = (folder / "runtime.log").open("w", buffering=1)
sys.stdout = sys.stderr = log
faulthandler.enable(file=log)
faulthandler.dump_traceback_later(30, file=log)
QSettings.setDefaultFormat(QSettings.Format.IniFormat)
for scope in (QSettings.Scope.UserScope, QSettings.Scope.SystemScope):
    QSettings.setPath(QSettings.Format.IniFormat, scope, str(folder / "settings"))
from core import autosave
autosave.autosave_dir = lambda: folder / "autosave"
(folder / "autosave").mkdir(exist_ok=True)

def setup(app):
    def run():
        report = {"checks": []}
        try:
            window, vp = app.window, app.viewport
            window._autosave_timer.stop()
            controller = window._lineas_color_controllers["lineas_color"]
            import ingetrazo_plugin_lineas_color as plugin
            report["version"] = plugin.__version__
            report["native_pick_signature"] = str(inspect.signature(controller.renderer.pick))
            vp._pick_index()
            report["checks"].append("startup picking")
            from ingetrazo_plugin_lineas_color.model import make_line
            vp.scene.mesh.clear()
            vp.scene.groups.clear()
            reference = make_line(V(1, 0, 1), V(5, 0, 1), "#e53935", pattern="dashed")
            vp.scene.groups.append(reference)
            vp.scene.version += 1
            vp.notify_scene_changed()
            vp.camera.perspective = False
            vp.camera.set_view("front")
            vp.camera.fit_to(V(-2, -1, -1), V(8, 1, 6))

            def mouse(kind, point, button, buttons, modifiers=Qt.NoModifier):
                return QMouseEvent(kind, QPointF(point), button, buttons, modifiers)

            center = QPointF(vp.rect().center())
            before = (vp.camera.yaw, vp.camera.pitch)
            vp.mousePressEvent(mouse(QEvent.MouseButtonPress, center, Qt.MiddleButton, Qt.MiddleButton))
            vp.mouseMoveEvent(mouse(QEvent.MouseMove, center + QPointF(42, 18), Qt.NoButton, Qt.MiddleButton))
            vp.mouseReleaseEvent(mouse(QEvent.MouseButtonRelease, center + QPointF(42, 18), Qt.MiddleButton, Qt.NoButton))
            assert before != (vp.camera.yaw, vp.camera.pitch)
            report["checks"].append("orbit")
            before = V(vp.camera.target)
            vp.mousePressEvent(mouse(QEvent.MouseButtonPress, center, Qt.MiddleButton, Qt.MiddleButton, Qt.ShiftModifier))
            vp.mouseMoveEvent(mouse(QEvent.MouseMove, center + QPointF(24, 12), Qt.NoButton, Qt.MiddleButton, Qt.ShiftModifier))
            vp.mouseReleaseEvent(mouse(QEvent.MouseButtonRelease, center + QPointF(24, 12), Qt.MiddleButton, Qt.NoButton, Qt.ShiftModifier))
            assert (vp.camera.target - before).length() > 1e-6
            report["checks"].append("pan")
            before = vp.camera.distance
            vp.wheelEvent(QWheelEvent(center, center, QPoint(0, 0), QPoint(0, 120),
                                     Qt.NoButton, Qt.NoModifier, Qt.NoScrollPhase, False))
            assert vp.camera.distance != before
            report["checks"].append("zoom")

            vp.camera.set_view("front")
            vp.camera.fit_to(V(-2, -1, -1), V(8, 1, 6))
            controller.start_drawing()
            def hover(point):
                pixel = QPointF(*vp._world_to_pixel(point))
                vp._process_hover(pixel, Qt.NoModifier)
                return pixel
            hover(V(3, 0, 1))
            assert vp.last_snap.kind == "midpoint"
            pixel = hover(V(1, 0, 1))
            assert vp.last_snap.kind == "endpoint"
            report["checks"].append("styled edge references")
            for point in (V(1, 0, 1), V(3, 0, 4), V(5, 0, 1)):
                pixel = hover(point)
                vp.mousePressEvent(mouse(QEvent.MouseButtonPress, pixel, Qt.LeftButton, Qt.LeftButton))
                vp.mouseReleaseEvent(mouse(QEvent.MouseButtonRelease, pixel, Qt.LeftButton, Qt.NoButton))
            assert vp.history.last_error is None
            group = controller.tool.session.group
            assert len(group.mesh.edges) == 2 and group in vp.scene.groups
            assert len(vp.scene.groups) == 2
            report["checks"].append("two connected drawn segments")
            report["languages"] = {}
            for code, caption, cancel in (("en", "Draw coloured line", "Cancel"),
                                         ("fr", "Tracer une ligne de couleur", "Annuler"),
                                         ("es", "Dibujar línea de color", "Cancelar")):
                start = V(controller.tool.start_point)
                controller.language_combo.setCurrentIndex(controller.language_combo.findData(code))
                assert controller.draw_button.text() == caption
                assert controller.tool.session.group is group and controller.tool.start_point == start
                dialog = controller.create_color_dialog()
                assert cancel in [button.text() for button in dialog.findChildren(QAbstractButton)]
                dialog.deleteLater()
                controller.app.show_panel(controller.dock)
                for _ in range(3):
                    QApplication.processEvents()
                controller.panel.grab().save(str(folder / f"panel_{code}.png"))
                report["languages"][code] = caption
            report["checks"].append("Spanish, English and French UI during drawing")
            assert vp.history.undo() and len(group.mesh.edges) == 1
            assert vp.history.redo() and len(group.mesh.edges) == 2
            report["checks"].append("undo and redo")
            for _ in range(3):
                QApplication.processEvents()
            assert not controller.renderer.failed and vp.isValid()
            image = vp.grabFramebuffer()
            assert not image.isNull()
            image.save(str(folder / "frame.png"))
            report["checks"].append("OpenGL drawing")
            report["ok"] = True
        except BaseException as error:
            report["ok"] = False
            report["error"] = type(error).__name__ + ": " + str(error)
            traceback.print_exc(file=log)
        (folder / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        log.flush()
        os._exit(0 if report["ok"] else 1)
    QTimer.singleShot(1000, run)
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app", default="/Applications/IngeTrazo.app/Contents/MacOS/ingetrazo")
    parser.add_argument("--plugin-zip", type=Path)
    parser.add_argument("--expect-failure", action="store_true")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="ja-lineastyle-frozen-") as temporary:
        folder = Path(temporary)
        plugins = folder / "data/ingetrazo/plugins"
        plugins.mkdir(parents=True)
        if args.plugin_zip:
            with ZipFile(args.plugin_zip) as archive:
                for name in archive.namelist():
                    if not name.startswith("lineas_color/"):
                        continue
                    if name.startswith("/") or ".." in Path(name).parts:
                        raise ValueError("Unsafe ZIP path")
                    archive.extract(name, plugins)
        else:
            shutil.copytree(ROOT / "JA_LineaStyle_IngeTrazo/lineas_color", plugins / "lineas_color",
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        (plugins / "zz_lineastyle_runtime_probe.py").write_text(PROBE, encoding="utf-8")
        environment = dict(os.environ, XDG_DATA_HOME=str(folder / "data"),
                           JA_LINEASTYLE_PROBE_DIR=str(folder), QT_QPA_PLATFORM="cocoa")
        try:
            result = subprocess.run([args.app, "--new-window"], env=environment,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45)
        except subprocess.TimeoutExpired as error:
            if (folder / "runtime.log").exists():
                print((folder / "runtime.log").read_text())
            raise RuntimeError("The isolated application probe timed out") from error
        if not (folder / "report.json").is_file():
            print(result.stdout.decode("utf-8", "replace"))
            if (folder / "runtime.log").exists():
                print((folder / "runtime.log").read_text())
            raise RuntimeError("The application did not produce a probe report")
        report = json.loads((folder / "report.json").read_text())
        target = ROOT / "previews"
        target.mkdir(exist_ok=True)
        version = report.get("version", "unknown")
        for filename, suffix in (("report.json", "json"), ("runtime.log", "log"), ("frame.png", "png")):
            path = folder / filename
            if path.is_file():
                shutil.copy2(path, target / f"ja_lineastyle_app_{version}.{suffix}")
        for code in report.get("languages", {}):
            path = folder / f"panel_{code}.png"
            if path.is_file():
                shutil.copy2(path, target / f"ja_lineastyle_app_{version}_panel_{code}.png")
        print(json.dumps(report, ensure_ascii=False, indent=2))
        if args.expect_failure:
            assert not report["ok"] and "unexpected keyword argument 'near'" in report.get("error", "")
        else:
            assert report["ok"], report.get("error")


if __name__ == "__main__":
    main()
