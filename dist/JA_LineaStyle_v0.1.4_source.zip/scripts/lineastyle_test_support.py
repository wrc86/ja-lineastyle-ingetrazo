# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Julio Angulo
"""Standalone source-release conftest: real host, isolated Qt and autosave."""
from pathlib import Path
import os
import stat
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".reference" / "ingetrazo"))

import pytest
from PySide6.QtCore import QLibraryInfo, QSettings
from PySide6.QtWidgets import QApplication


@pytest.fixture(scope="session", autouse=True)
def qt_app(tmp_path_factory):
    if sys.platform == "darwin":
        plugins = Path(QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath))
        for kind in ("platforms", "imageformats", "iconengines"):
            for library in (plugins / kind).glob("*.dylib"):
                flags = library.stat().st_flags
                if flags & stat.UF_HIDDEN:
                    os.chflags(library, flags & ~stat.UF_HIDDEN)
    app = QApplication.instance() or QApplication([])
    app.setOrganizationName("JA-LineaStyle-Tests")
    app.setApplicationName("Isolated")
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    path = str(tmp_path_factory.mktemp("settings"))
    for scope in (QSettings.Scope.UserScope, QSettings.Scope.SystemScope):
        QSettings.setPath(QSettings.Format.IniFormat, scope, path)
    from core import autosave
    original = autosave.autosave_dir
    isolated_autosave = Path(path) / "autosave"
    isolated_autosave.mkdir()
    autosave.autosave_dir = lambda: isolated_autosave
    yield app
    autosave.autosave_dir = original
