# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Julio Angulo
"""Produce an isolated native Qt preview and a sample IGZ (no installation)."""
from pathlib import Path
import os
import stat
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".reference" / "ingetrazo"))
from PySide6.QtCore import QLibraryInfo, QPointF, QRectF, QSettings, Qt
from PySide6.QtGui import QColor, QImage, QPainter, QVector3D as V
from PySide6.QtWidgets import QApplication, QMenu, QTabBar

if sys.platform == "darwin":
    plugins = Path(QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath))
    for kind in ("platforms", "imageformats", "iconengines"):
        for library in (plugins / kind).glob("*.dylib"):
            flags = library.stat().st_flags
            if flags & stat.UF_HIDDEN:
                os.chflags(library, flags & ~stat.UF_HIDDEN)

qt_app = QApplication([])
qt_app.setOrganizationName("JA-LineaStyle-Preview")
qt_app.setApplicationName("Isolated")
QSettings.setDefaultFormat(QSettings.Format.IniFormat)
settings_dir = tempfile.mkdtemp(prefix="ja-lineastyle-preview-")
for scope in (QSettings.Scope.UserScope, QSettings.Scope.SystemScope):
    QSettings.setPath(QSettings.Format.IniFormat, scope, settings_dir)

from core import extensions, i18n
from views.main_window import MainWindow
from formats import igz

i18n.set_language("es")
extensions.plugin_dirs = lambda: [ROOT / "JA_LineaStyle_IngeTrazo"]
window = MainWindow()
window._autosave_timer.stop()
vp = window.viewport
vp.scene.groups.clear()
vp.scene.mesh.clear()
controller = window._lineas_color_controllers["lineas_color"]
from ingetrazo_plugin_lineas_color.model import AddSessionSegment, DrawingSession

# Six display patterns and a connected, native plane in ONE shared mesh.
session = DrawingSession(vp)
from ingetrazo_plugin_lineas_color.styles import PATTERNS
colors = ["#e53935", "#fb8c00", "#43a047", "#1e88e5", "#8e24aa", "#20252b"]
for index, ((pattern, _label, _lengths), color) in enumerate(zip(PATTERNS, colors)):
    z = 3 - index * 0.48
    vp.history.execute(AddSessionSegment(session, V(-3, -1, z), V(0.5, -1, z), color, 3, pattern))
points = [V(1.1, -1, 0.6), V(3.1, -1, 0.6), V(3.1, -1, 3), V(1.1, -1, 3), V(1.1, -1, 0.6)]
for a, b in zip(points, points[1:]):
    vp.history.execute(AddSessionSegment(session, a, b, "#1e88e5", 3, "dash_dot"))
vp.history.execute(AddSessionSegment(session, points[0], points[2], "#e53935", 2, "dashed"))
if vp.history.last_error or len(session.group.mesh.faces) != 2 or session.group.children:
    raise RuntimeError("The example must contain two connected faces without subgroups.")
controller.width_spin.setValue(3)
controller.pattern_combo.setCurrentIndex(4)
style = vp.scene.display_style
style.face_mode, style.sky, style.profiles = "hidden_line", False, False
style.background = (0.97, 0.98, 0.99)
vp.camera.perspective = False
vp.camera.set_view("front")
vp.camera.set_aspect(1000, 650)
vp.camera.fit_to(V(-3.4, -1, 0), V(3.5, 1, 3.4))
vp.scene.version += 1
vp.notify_scene_changed()
window.resize(1250, 820)
window.show()
controller.app.show_panel(controller.dock)
for _ in range(12):
    qt_app.processEvents()
target = ROOT / "previews"
target.mkdir(exist_ok=True)
panel = controller.panel
panel.grab().save(str(target / "ja_lineastyle_panel.png"))
tabs = [(bar, index) for bar in window.findChildren(QTabBar)
        for index in range(bar.count()) if bar.tabText(index) == "LineaStyle"]
if not tabs or any(bar.tabIcon(index).pixmap(16, 16).isNull() for bar, index in tabs):
    raise RuntimeError("The panel tab must show LineaStyle with its icon.")
for bar, index in tabs:
    bar.setCurrentIndex(index)
for _ in range(3):
    qt_app.processEvents()
bar, index = max(tabs, key=lambda tab: tab[0].width())
bar.grab(bar.tabRect(index)).save(str(target / "ja_lineastyle_tab.png"))
controller.icon.pixmap(128, 128).save(str(target / "ja_lineastyle_icon.png"))
menu = QMenu("Extensiones", window)
menu.addAction(controller.menu_action)
menu.ensurePolished()
menu.resize(menu.sizeHint())
menu.grab().save(str(target / "ja_lineastyle_menu.png"))
# Display the actual native cursor at 3x for inspection on both backgrounds.
controller.start_drawing()
samples = [("Rojo", "#e53935"), ("Naranja", "#fb8c00"), ("Verde", "#43a047"),
           ("Azul", "#1e88e5"), ("Negro", "#20252b"), ("Blanco", "#ffffff")]
cursor_preview = QImage(720, 344, QImage.Format.Format_ARGB32_Premultiplied)
cursor_preview.fill(QColor("#f7f9fb"))
painter = QPainter(cursor_preview)
try:
    font = painter.font()
    font.setPixelSize(18)
    painter.setFont(font)
    painter.setPen(QColor("#263238"))
    painter.drawText(QRectF(0, 0, 720, 42), Qt.AlignmentFlag.AlignCenter,
                     "JA LineaStyle · Lápiz del color seleccionado")
    for row, (background, text_color) in enumerate((("#f7f9fb", "#263238"),
                                                  ("#263238", "#ffffff"))):
        top = 44 + row * 150
        painter.fillRect(QRectF(0, top, 720, 150), QColor(background))
        for column, (label, color) in enumerate(samples):
            controller.choose(color)
            pencil = vp.cursor().pixmap()
            painter.save()
            painter.translate(column * 120 + 12, top + 8)
            painter.scale(3, 3)
            painter.drawPixmap(0, 0, pencil)
            painter.restore()
            font.setPixelSize(13)
            painter.setFont(font)
            painter.setPen(QColor(text_color))
            painter.drawText(QRectF(column * 120, top + 112, 120, 28),
                             Qt.AlignmentFlag.AlignCenter, label)
finally:
    painter.end()
cursor_preview.save(str(target / "ja_lineastyle_cursor.png"))
if vp._gl is None or not vp.isValid():
    raise RuntimeError("Run with QT_QPA_PLATFORM=cocoa on macOS for the 3D preview.")
image = vp.render_image(1200, height_px=780, overlays=False)
if image is None or image.isNull() or controller.renderer.failed:
    raise RuntimeError("The colour-lines renderer did not produce an image.")
image.save(str(target / "ja_lineastyle_modelo.png"))
vp.scene.camera_home = window._camera_dict()
igz.save_scene(vp.scene, ROOT / "JA_LineaStyle_IngeTrazo" / "Ejemplo_JA_LineaStyle.igz")
# A genuine screen-position hover must now find a styled edge endpoint.
controller.choose("#1e88e5")
reference = V(-3, -1, 3)
pixel = vp._world_to_pixel(reference)
vp._process_hover(QPointF(*pixel), Qt.KeyboardModifier.NoModifier)
if vp.last_snap.kind != "endpoint" or (vp.last_snap.point - reference).length() > 1e-5:
    raise RuntimeError("The styled endpoint did not offer a native drawing reference.")
for _ in range(3):
    qt_app.processEvents()
vp.grabFramebuffer().save(str(target / "ja_lineastyle_referencia.png"))
print(target / "ja_lineastyle_modelo.png")
print(target / "ja_lineastyle_panel.png")
print(target / "ja_lineastyle_cursor.png")
print(target / "ja_lineastyle_referencia.png")
window.hide()
window.deleteLater()
