# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Julio Angulo
"""Build matching installation and repository-ready source archives."""
import ast
from hashlib import sha256
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "JA_LineaStyle_IngeTrazo"
DOCS = ("README.md", "MANUAL.md", "LICENSE", "CHANGELOG.md", "CONTRIBUTING.md", "NOTICES.md")
MODULES = ("__init__.py", "controller.py", "cursor.py", "model.py", "patterns.py", "render.py", "styles.py", "tool.py")


def version():
    tree = ast.parse((PROJECT / "lineas_color/__init__.py").read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "__version__"
                                               for t in node.targets):
            value = ast.literal_eval(node.value)
            if isinstance(value, str) and re.fullmatch(r"\d+\.\d+\.\d+", value):
                return value
    raise ValueError("Falta una versión válida en lineas_color/__init__.py.")


def build():
    release_version = version()
    dist = ROOT / "dist"
    dist.mkdir(exist_ok=True)
    install = dist / f"JA_LineaStyle_v{release_version}.zip"
    sources = dist / f"JA_LineaStyle_v{release_version}_source.zip"
    entries = [*(Path("lineas_color") / name for name in MODULES),
               Path("lineas_color/LICENSE"), Path("lineas_color/icons/ja_lineastyle.svg"),
               *(Path(f"lineas_color/icons/ja_lineastyle_{size}.png") for size in (16, 32, 64, 128)),
               *(Path(name) for name in DOCS), Path("Ejemplo_JA_LineaStyle.igz")]
    for relative in entries:
        if not (PROJECT / relative).is_file():
            raise FileNotFoundError(f"Falta {relative}; genere primero el ejemplo con el script de preview.")
    for name in MODULES:
        text = (PROJECT / "lineas_color" / name).read_text(encoding="utf-8")
        if not text.startswith("# SPDX-License-Identifier: GPL-3.0-or-later\n"):
            raise ValueError(f"Falta el aviso de licencia en {name}.")
    if (PROJECT / "LICENSE").read_bytes() != (PROJECT / "lineas_color/LICENSE").read_bytes():
        raise ValueError("Las dos copias de la licencia no coinciden.")
    with ZipFile(install, "w", compression=ZIP_DEFLATED) as archive:
        for relative in entries:
            archive.write(PROJECT / relative, relative.as_posix())
    with ZipFile(sources, "w", compression=ZIP_DEFLATED) as archive:
        for relative in entries:
            archive.write(PROJECT / relative, (Path(PROJECT.name) / relative).as_posix())
        for name in DOCS:
            archive.write(PROJECT / name, name)
        for name in ("tests/test_ja_lineastyle.py", "scripts/build_ja_lineastyle_release.py",
                     "scripts/preview_ja_lineastyle.py", "scripts/lineastyle_test_support.py",
                     "scripts/render_ja_lineastyle_icon.py", "scripts/probe_ja_lineastyle_app.py"):
            archive.write(ROOT / name, name)
        archive.write(ROOT / "scripts/lineastyle_test_support.py", "tests/conftest.py")
        archive.writestr(".gitignore", "dev-env/\n.venv/\n.reference/\n.plugin_backups/\n__pycache__/\n*.pyc\n.pytest_cache/\n.DS_Store\ndist/\npreviews/\n")
    for path in (install, sources):
        with ZipFile(path) as archive:
            if archive.testzip() is not None:
                raise ValueError(f"ZIP dañado: {path.name}")
            assert not any(name.startswith("/") or ".." in Path(name).parts
                           or "__pycache__" in name or name.endswith(".pyc")
                           for name in archive.namelist())
        print(path)
    sums = dist / f"JA_LineaStyle_v{release_version}_SHA256SUMS.txt"
    sums.write_text("".join(f"{sha256(path.read_bytes()).hexdigest()}  {path.name}\n"
                            for path in (install, sources)), encoding="utf-8")
    print(sums)


if __name__ == "__main__":
    build()
